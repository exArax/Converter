class Action:
    def set_name(self, name):
        self.__name = name

    def get_name(self):
        return self.__name

    def set_order(self, order):
        self.__order = order

    def get_order(self):
        return self.__order



