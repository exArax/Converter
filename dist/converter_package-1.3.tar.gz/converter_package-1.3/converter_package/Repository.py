class Repository:
    def set_path(self, path):
        self.__path = path

    def get_path(self):
        return self.__path

    def set_version(self, version):
        self.__version = version

    def get_version(self):
        return self.__version

    def set_id(self, id):
        self.__id = id

    def get_id(self):
        return self.__id

    def set_size(self, size):
        self.__size = size

    def get_size(self):
        return self.__size

    def set_imageName(self,name):
        self.__imageName = name

    def get_imageName(self):
        return self.__imageName

    def set_component(self, component):
        self.__component = component

    def get_component(self):
        return  self.__component
