class Workflows:
    def set_actionlist(self, actionlist):
        self.__actionlist = actionlist

    def get_actionlist(self):
        return self.__actionlist

    def set_scenario(self, scenario):
        self.__scenario = scenario

    def get_scenario(self):
        return self.__scenario

    def set_condition(self, condition):
        self.__condition = condition

    def get_condition(self):
        return self.__condition


