class Image:

    def set_component(self, component):
        self.__component = component

    def get_component(self):
        return self.__component

    def set_image_name(self, image):
        self.__image = image

    def get_image_name(self):
        return self.__image

    def set_image_type(self, type):
        self.__type = type

    def get_image_type(self):
        return self.__type

    def set_path(self, path):
        self.__path = path

    def get_path(self):
        return self.__path



